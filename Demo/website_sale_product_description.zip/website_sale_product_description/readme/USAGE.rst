Once installed, website description is editable from product form:

.. figure:: ../static/description/product.png
   :alt: Kanban view
   :width: 600 px

Then, this description will be shown within the e-Commerce product page:

.. figure:: ../static/description/website-product.png
   :alt: Kanban view
   :width: 600 px
