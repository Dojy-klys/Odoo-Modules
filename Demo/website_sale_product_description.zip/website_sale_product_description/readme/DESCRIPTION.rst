With this addon you can edit a specific HTML description for a product.
This description will be shown within the e-Commerce product page.
